﻿#include <iostream>
#include <ctime>
#include <iomanip>
#include <fstream>
#include <string>


using namespace std;



class HiraganaFull
{
private:

	string TheHiraganachar[46];
public:
	//gets all the hiragara words
	void FindAll()
	{
		ifstream TheHiragana;
		TheHiragana.open("Hiragana.txt");
		if (TheHiragana.is_open())
		{
			int ten = 0;
			while (TheHiragana)
			{
				TheHiragana >> TheHiraganachar[ten];
				ten++;
			}
		}
		TheHiragana.close();
	}
	//returns the desaired word
	string getword(int tem)
	{
		return TheHiraganachar[tem];
	}
};


int main()
{
	HiraganaFull HigaInfo;
    HigaInfo.FindAll();
    srand(time(0));
	
    int MIN =1;
    int MAX ;
	int menuechoice;
	cout << " 1:Single ROW\n 2:Multiple ROW's\n Enter a choice: ";
	cin >> menuechoice;

	switch (menuechoice)
	{
	 case(1):
	 {
		 //gets the rigth max and min
		 cout << "which ROW do you want?: ";
		 cin >> MAX;
		 MAX *= 5;
		 MIN = MAX;
		 MIN -= 4;

		 bool untill = 1;

		 cout << "Tap 1 to start or 0 to end: ";
		 cin >> untill;
		 //save random number for array
		 int temp;
		 //mistakes
		 int wrong = 0;
		 //infinitly untill user stops
		 while (untill)
		 {
			 if (untill == 1)
			 {
				 char tempo;
				 temp = (rand() % (MAX - MIN + 1)) + MIN;
				 temp -= 1;

				 // display the random word		 
				 cout << "                        -----------------------------------------------" << endl;
				 cout << "                        |                                            ||" << endl;
				 cout << "                        |" << setw(21) << "Write:" << HigaInfo.getword(temp) << setw(24) << "| " << "Mistakes " << wrong << endl;
				 cout << "                        |                                            ||" << endl;
				 cout << "                        -----------------------------------------------" << endl;

				 //user gets the option to stop 
				 cout << "Did you get it right ? y / n" << endl;
				 cin >> tempo;
				 if (tempo == 'N' || tempo == 'n')
				 {
					 wrong++;
					 cout << "Do you want to contine Y/N: ";
					 cin >> tempo;
					 if (tempo == 'N' || tempo == 'n')
					 {
						 untill = false;
					 }
				 }
			 }
			 else
			 {
				 untill = false;
			 }
		 }
		break;
	 }
	 case(2):
	 {



		 cout << "How many ROW's: ";
		 cin >> MAX;
		 MAX *= 5;
		 bool untill = 1;

		 cout << "Tap 1 to start or 0 to end: ";
		 cin >> untill;
		 //save random number for array
		 int temp;
		 int wrong = 0;
		 //infinitly untill user stops
		 while (untill)
		 {
			 if (untill == 1)
			 {
				 char tempo;
				 temp = (rand() % (MAX - MIN + 1)) + MIN;
				 temp -= 1;

				 // display the random word		 
				 cout << "                        -----------------------------------------------" << endl;
				 cout << "                        |                                            ||" << endl;
				 cout << "                        |" << setw(21) << "Write:" << HigaInfo.getword(temp) << setw(24) << "| " << "Mistakes " << wrong << endl;
				 cout << "                        |                                            ||" << endl;
				 cout << "                        -----------------------------------------------" << endl;

				 //user gets the option to stop 
				 cout << "Did you get it right ? y / n" << endl;
				 cin >> tempo;
				 if (tempo == 'N' || tempo == 'n')
				 {
					 wrong++;
					 cout << "Do you want to contine Y/N: ";
					 cin >> tempo;
					 if (tempo == 'N' || tempo == 'n')
					 {
						 untill = false;
					 }
				 }
			 }
			 else
			 {
				 untill = false;
			 }
		 }
		 break;
	 }
	 

	}



	

	
	
	



	
}