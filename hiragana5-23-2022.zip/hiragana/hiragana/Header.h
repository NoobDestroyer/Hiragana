#pragma once
class HiraganaFull
{
private:

	string TheHiraganachar[46];
public:
	//gets all the hiragara words
	void FindAll()
	{
		ifstream TheHiragana;
		TheHiragana.open("Hiragana.txt");
		if (TheHiragana.is_open())
		{
			int ten = 0;
			while (TheHiragana)
			{
				TheHiragana >> TheHiraganachar[ten];
				ten++;
			}
		}
		TheHiragana.close();
	}
	//returns the desaired word
	string getword(int tem)
	{
		return TheHiraganachar[tem];
	}
};