﻿#include <iostream>
#include <ctime>
#include <iomanip>
using namespace std;


const int MIN = 1;



int main()
{
	
	int MAX ;
	string Hiragana[10]{ "A","I","U","E","O","KA","KI","KU","KE","Ko" };
	srand(time(0));

	cout << "How many ROW's: ";
	cin >> MAX;
	MAX *= 5;








	bool untill=1;
 cout << "Tap 1 to start or 0 to end:";
 cin >> untill;
 int temp;


	while (untill)
	{
		if(untill==1)
		{
			char tempo;
	
             temp = (rand() %(MAX - MIN + 1)) + MIN;
			 temp -= 1;
			// cout << "number" << temp<<endl;
		 
		 cout << "-----------------------------------------------" << endl;
		 cout << "|                                            ||" << endl;
		 cout << "|"<<setw(25)<<"Write "<< Hiragana[temp]<<setw(20)<<"| " << endl;
		 cout << "-----------------------------------------------" << endl;
		 
		 cout << "Did you get it right ? y / n"<<endl;
		 cin >> tempo;
		 if (tempo == 'N' || tempo == 'n')
		 {
			 cout << "Do you want to contine Y/N: ";
			 cin >> tempo;
			 if (tempo == 'N' || tempo == 'n')
			 {
				 untill = false;
			 }
		 }
		 
		}
		else
		{
			untill = false;
		}
	}
}




